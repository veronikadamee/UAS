    <footer>
        <p>&copy; Universitas Pelita Bangsa 2021 - Alfansha Abiftyo Hadyatama - 311910321 - TI.19.A.2</p>
    </footer>
    </div>
</body>
</html>
